
import streamlit as st
from gtts import gTTS
import speech_recognition as sr
import os
import tempfile
from PIL import Image

st.set_page_config(page_title="Krishi Sakhi", page_icon="🌱", layout="centered")

# Function for audio playback
def speak(text, lang='ml'):
    tts = gTTS(text=text, lang=lang)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.mp3')
    tts.save(tmp.name)
    audio_file = open(tmp.name, 'rb')
    st.audio(audio_file.read(), format='audio/mp3')
    audio_file.close()

# Function for speech to text
def listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        st.write("🎤 Listening...")
        audio = recognizer.listen(source)
    try:
        text = recognizer.recognize_google(audio, language="ml-IN")
        return text
    except:
        return "Could not understand"

# UI Styling
st.markdown("""<style>
body { background-color: #f6fff6; }
h1, h2, h3, h4 { color: #228B22; font-family: Arial; }
</style>""", unsafe_allow_html=True)

st.image("logo.png", width=150)
st.title("🌱 Krishi Sakhi - Farmer Assistant")

# Step 1: Language Selection
st.header("Step 1: Choose Language")
language = st.radio("Select Language:", ["മലയാളം", "English"])

# Voice prompt for name
st.header("Step 2: Basic Details")
if st.button("🎤 Speak Your Name"):
    speak("നിങ്ങളുടെ പേര് പറയുക" if language == "മലയാളം" else "Say your name")
    name = listen()
    st.success(f"Name: {name}")
else:
    name = st.text_input("Enter your name")

mobile = st.text_input("Enter Mobile Number")

# Step 3: Location
st.header("Step 3: Location")
speak("നിങ്ങളുടെ സ്ഥലം പറയുക" if language == "മലയാളം" else "Say your location")
location = st.text_input("Enter Location (GPS Auto-fetch Coming Soon)")

# Step 4: Farm Details
st.header("Step 4: Farm Details")
land_size = st.text_input("Land Size (in acres)")
water_source = st.radio("Water Source", ["💧 Well", "🌧 Rain", "🚰 Canal", "🔘 Borewell"])
irrigation_method = st.radio("Irrigation Method", ["💦 Drip", "💨 Sprinkler", "🌊 Flood"])
soil_type = st.radio("Soil Type", ["Clay", "Sandy", "Loamy", "Laterite"])

# Step 5: Crop Details with icons
st.header("Step 5: Crop Details")
st.write("Select Current Crop:")
col1, col2, col3, col4 = st.columns(4)
with col1:
    if st.button("🌾 Paddy"): current_crop = "Paddy"
with col2:
    if st.button("🍌 Banana"): current_crop = "Banana"
with col3:
    if st.button("🥥 Coconut"): current_crop = "Coconut"
with col4:
    if st.button("🥦 Vegetables"): current_crop = "Vegetables"

variety_name = st.text_input("Variety Name (optional)")
date_of_sowing = st.date_input("Date of Sowing (Leave empty if not applicable)")
season = st.radio("Season", ["Kharif", "Rabi", "Summer"])

# Step 6: Preferences
st.header("Step 6: Preferences")
farming_type = st.radio("Farming Type", ["Organic", "Chemical"])
communication_mode = st.multiselect("Preferred Communication Mode", ["SMS", "WhatsApp", "Voice Call"])
reminder_pref = st.selectbox("Reminders Preference", ["Daily", "Weekly", "Only Critical Alerts"])

# Submit
if st.button("✅ Complete Profile"):
    st.success("Profile Created Successfully!")
    st.write(f"Name: {name}, Mobile: {mobile}")
    st.write(f"Crop: {current_crop if 'current_crop' in locals() else 'Not Selected'}, Land Size: {land_size} acres")
    st.write(f"Communication: {communication_mode}")
